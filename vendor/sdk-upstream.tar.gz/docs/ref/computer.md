# `Computer`

::: agents.computer
