# `Model`

::: agents.testing.model
